package com.huntgame.UtilitiyFile;

public class StaticValues {

	public static String UrlLink = "http://www.sicsglobal.com/projects/App_projects/hunt/";

}
