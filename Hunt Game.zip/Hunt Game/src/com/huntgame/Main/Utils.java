package com.huntgame.Main;

import android.app.Application;

public class Utils extends Application {

	public static String GCMSenderId = "830215591309";// "721787675032";

	public static boolean notificationReceived;

	public static String notiTitle = "", notiGameName = "", notiGameID = "",
			notistartingDate = "", notiendingDate = "", notigameType = "",
			notimoderatorStatus = "", notilatitude = "", notilongitude = "",
			notilocation = "", notistatus = "", notiuserName = "",
			registrationId = "", pushnotificationTag = ""; // create Game

	public static String notiHuntername = "", notiFujiTiveName = "",
			notiHunterId = "", notiFujitiveId = "", notiFujitiveImage = "",
			notiHunterImage = "", notiMessage = "", notiCapturedImage = "";

	public static String notiModeratorName = "";

	public static String notiUserName = "", notiUserImg = "",
			notiUserResponse = "";

}